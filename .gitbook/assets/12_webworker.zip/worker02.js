onmessage = function(event) {
	var su = event.data;
	var sum = 0, i;
	for (i = 0; i <= su; i++) {
		sum += i;
	}
	postMessage(su + "  Cumulative value  => " + sum);
};


