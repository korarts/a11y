var convertFile;
if ( "FileReaderSync" in self) { 
    var reader = new FileReaderSync ();
    convertFile = function (file) {
        if (file.type.match (/image.*/)) {
            var data = reader.readAsDataURL (file);
            return "<img src = '" + data + "'>";
        } else if (file.type.match (/text.*/)) {
            return reader.readAsText (file);
        } else {
                return file.name;
        }
    };
} else { 
    convertFile = function (file) {
        return file.name;
    };
}


