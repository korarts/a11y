onmessage = function(event) {

	var sr = parseInt(event.data) * 2;

	event.target.postMessage(sr);
};

