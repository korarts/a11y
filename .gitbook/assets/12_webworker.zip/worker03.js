onmessage = function(e) {
	var num2 = Math.pow(10, e.data);
	var flag = false;
	
	  var val1=0;
	  var val2=0;
	while (!flag) {
		val1 = Math.floor(Math.random() * parseInt(num2));
		val2 = Math.floor(Math.random() * parseInt(num2));
		if (val1 == val2) {
			flag = true;
		}
	}
	postMessage(val1);
};
