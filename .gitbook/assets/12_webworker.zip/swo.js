importScripts ( 'swo02.js');

var images = "";
var ports = new Array ();

var comments = new Array ();

onmessage = function (event) {
    images = convertFile (event.data) + "<br>"+ images;
    event.target.postMessage (images);
};

onconnect = function (event) {
    var port = event.ports [0];
    ports.push (port);
    port.onmessage = function (event) { 
       comments.push (event.data);
       for (var i = 0; i <ports.length; i ++) {
           ports [i]. postMessage (comments);
       }
    };
};




