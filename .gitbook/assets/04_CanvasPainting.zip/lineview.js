function draw_line() {
	var canvas = document.getElementById('canvas');
	context = canvas.getContext('2d');

	

	context.lineWidth = '4';
	context.beginPath();
	context.moveTo(97, 0);
	context.lineTo(131, 57);
	context.lineTo(205, 68);
	context.lineTo(151, 120);
	context.lineTo(164, 195);
	context.lineTo(97, 160);
	context.lineTo(31, 195);
	context.lineTo(43, 120);
	context.lineTo(0, 68);
	context.lineTo(64, 57);
	context.lineTo(97, 0);
	context.fillStyle = "rgba(0, 0, 0, 0.5)";
	context.fill();
	context.stroke();
	context.closePath();

}
