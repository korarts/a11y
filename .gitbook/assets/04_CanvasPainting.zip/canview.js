window.onload = function() {
	var element = document.getElementById('canvas');
	if (element.getContext) {
		this.context = element.getContext('2d');
		show('canvas_width ', context.canvas.width);
	} else {
		alert('Context not supported');
		return;
	}
};
