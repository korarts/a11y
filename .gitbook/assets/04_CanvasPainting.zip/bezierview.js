function draw_bezier(){ 
	var canvas = document.getElementById('canvas'); 
	context = canvas.getContext('2d');

	context.strokeStyle = 'blue';	
	context.lineWidth = '4';
    context.beginPath();		
	context.moveTo(200,200);
	context.quadraticCurveTo(300,50,400,200);
	context.stroke();	
	context.closePath();
	
	context.beginPath();	
	context.strokeStyle = 'red';	
	context.moveTo ( 20,20 );
	context.bezierCurveTo ( 20,100 , 200,100,200,20);
	context.stroke();	
	context.closePath();
	
	
	
}


	
