function draw_rect() { 
	alert('canvas을 클릭하면 clearRect호출');
	var canvas = document.getElementById('canvas'); 
	context = canvas.getContext('2d');	
	context.lineWidth = 30;
	context.strokeStyle = 'blue';	
	context.strokeRect(75, 100, 200, 200);	
	context.fillStyle = "rgb(255,0,0)";  
	context.fillRect(325, 100, 200, 200);	
	context.canvas.onmousedown = function(e) {		
		context.clearRect(0, 0, canvas.width, canvas.height);
	};
}


