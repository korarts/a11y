function init() {
	Array.prototype.contains = function(value) {
		for ( var i in this) {
			if (this[i] == value) {
				return true;
			}
		}
		return false;
	};
}

function doDragStart(event) {
	event.dataTransfer.setData('text/plain', event.target.id);
}

function doDragOver(event) {
	var type = event.dataTransfer.types.contains("text/plain");
	if (type) {
		event.preventDefault();
	}
}

function doDrop(event) {
	var data = event.dataTransfer.getData(" text/plain");
	event.target.textContent = data;
	event.target.style.cssText = "background-color : #ffffff";
}





