// (1) Web Storage 구현 확인

if (typeof sessionStorage === 'undefined') {
	window.alert("이 브라우저는 Web Storage 기능이 구현 되어 있지 않습니다. ");
} else {
	window.alert("이 브라우저는 Web Storage 기능을 구현하고 있습니다");

	var storage = sessionStorage;

	// (2) sessionStorage에 저장
	function setsessionStorage() {
		var key = document.getElementById("textkey").value;
		var value = document.getElementById("textdata").value;
		// 값의 입력 체크
		if (key && value) {
			storage.setItem(key, value);
		}
		key = "";
		value = "";
		viewStorage();
	}
	// (3) sessionStorage에서 데이터 검색 및 표시
	function viewStorage() {
		var list = document.getElementById("list");
		while (list.firstChild) {
			list.removeChild(list.firstChild);
		}
		// sessionStorage 모든 정보의 취득
		for ( var i = 0; i < storage.length; i++) {
			var _key = storage.key(i);
			// sessionStorage의 키와 값을 표시
			var tr = document.createElement("tr");
			var td1 = document.createElement("td");
			var td2 = document.createElement("td");
			list.appendChild(tr);
			tr.appendChild(td1);
			tr.appendChild(td2);
			td1.innerHTML = _key;
			td2.innerHTML = storage.getItem(_key);
		}
	}
	// (4) sessionStorage에서 삭제
	function removeStorage() {
		var key = document.getElementById("textkey");
		storage.removeItem(key);
		key = "";
		viewStorage();
	}
	// (5) sessionStorage에서 삭제
	function removeallStorage() {
		storage.clear();
		viewStorage();
	}
}




