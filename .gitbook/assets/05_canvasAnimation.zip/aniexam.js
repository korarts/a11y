window.requestAnimFrame = (function(callback) {
	return window.requestAnimationFrame || window.webkitRequestAnimationFrame
			|| window.mozRequestAnimationFrame || window.oRequestAnimationFrame
			|| window.msRequestAnimationFrame || function(callback) {
				window.setTimeout(callback, 1000 / 60);
			};
})();

requestAnimFrame(function() {
	aniview(value, time);
});

function aniview(value, lastTime) {
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	var date = new Date();
	var time = date.getTime();
	var timediff = lastTime - time;
	value.ta += timediff * value.rotationSpeed / 1000;
	var img = new Image();
	img.src = 'cat.png';
	context.clearRect(0, 0, canvas.width, canvas.height);
	context.save();
	context.translate(canvas.width / 2, canvas.height / 2);
	context.scale(1, Math.sin(value.ta / 2));
	context.rotate(value.ta);
	context.drawImage(img, -value.width / 2, -value.height / 2, value.width,
			value.height);
	context.restore();
	requestAnimFrame(function() {
		aniview(value, time);
	});
}
window.onload = function() {
	var initvalue = {
		width : 200,
		height : 100,
		ta : 0,
		rotationSpeed : 3
	};
	var date = new Date();
	var time = date.getTime();
	aniview(initvalue, time);
};
