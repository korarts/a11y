function draw_text() {
	var canvas = document.getElementById('canvas');
	context = canvas.getContext('2d');

	gradient = context.createLinearGradient(50, 50, canvas.width - 150, 0);

	text = 'Hello Canvas! ';
	context.font = '125px Palatino';
	context.strokeStyle = 'blue';

	gradient.addColorStop(0, 'blue');
	gradient.addColorStop(0.5, 'red');
	gradient.addColorStop(0.6, 'white');
	gradient.addColorStop(0.8, 'green');
	gradient.addColorStop(1.0, 'yellow');
	context.fillStyle = gradient;
	context.fillText(text, 65, 200);
	context.strokeText(text, 65, 200);
}
