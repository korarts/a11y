var canvas = document.getElementById('canvas');
context = canvas.getContext('2d');
scaleSlider = document.getElementById('Slider');

image = new Image();
image.src = 'pcat.png';
scale = 1.0;
MINIMUM = 1.0;
MAXIMUM = 2.0;

function drawImage() {
	var w = canvas.width, h = canvas.height, sw = w * scale, sh = h * scale;

	context.clearRect(0, 0, canvas.width, canvas.height);
	context.drawImage(image, -sw / 2 + w / 2, -sh / 2 + h / 2, sw, sh);
}



scaleSlider.onchange = function(e) {
	scale = e.target.value;
	if (scale < MINIMUM)
		scale = MINIMUM;
	else if (scale > MAXIMUM)
		scale = MAXIMUM;
	drawImage();
};

image.onload = function(e) {
	drawImage();
};




