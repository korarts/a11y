var c = document.getElementById('canvas');
var context = c.getContext('2d');
var img = new Image();
img.src = 'cat.png';

function Imgdraw(value) {
	context.clearRect(0, 0, canvas.width, canvas.height);

	switch (value) {
	case 'scale':
		context.save();
		context.drawImage(img, 50, 50);
		context.scale(2, 2);
		context.drawImage(img, 100, 100);
		context.restore();
		break;
	case 'rotate':
		context.save();	
		context.rotate(45 * Math.PI / 180);
		context.drawImage(img, 250, 45);
		context.restore();
		break;
	case 'translate':
		context.save();	
		context.drawImage(img, 50, 50);
		context.translate(200, 200);
		context.drawImage(img, 50, 50);
		context.restore();
		break;
	}
}
