         function readFile() {
           var file = document.getElementById("file").files[0];

           document.getElementById("fileName").textContent = file.name;   
           document.getElementById("fileSize").textContent = file.size + " 바이트";
           document.getElementById("fileType").textContent = file.type;
           var reader = new FileReader();

           reader.onload = function() {
              var display = document.getElementById("content");
              display.textContent = reader.result;
           };

           reader.onerror = function(evt) {
              alert(evt.target.error.code);
          };

          var encodingList = document.getElementById("encoding");
          var encoding = encodingList.options[encodingList.selectedIndex].value; 

          reader.readAsText(file, encoding);
      }
 
