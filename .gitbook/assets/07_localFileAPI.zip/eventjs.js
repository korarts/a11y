var files;
function FileInfo() {
	files = document.getElementById("files list").files;
	var output = document.getElementById("output");

	while (output.childNodes.length != 0)
		output.removeChild(output.firstChild);

	var table = document.createElement("table");
	table.setAttribute("border", "4");
	table.setAttribute("cellPadding", "5");
	var tHead = document.createElement("tHead");
	table.appendChild(tHead);
	table.tHead.appendChild(document.createElement("tr"));

	var td = document.createElement("td");
	td.appendChild(document.createTextNode("Name"));
	table.tHead.rows[0].appendChild(td);
	td = document.createElement("td");
	td.appendChild(document.createTextNode("Size"));
	table.tHead.rows[0].appendChild(td);

	var tbody = document.createElement("tbody");
	table.appendChild(tbody);

	// 파일 목록 만큼 출력될 레이아웃과 목록 출력
	for ( var i = 0; i < files.length; i++) {
		table.tBodies[0].appendChild(document.createElement("tr"));
		td = document.createElement("td");
		var link = document.createElement("a");
		// 오류 이벤트가 발생처리와 데이타를 표시할 dumpFile 메소드를 link 속성에 지정
		link.setAttribute("href", "javascript: dumpFile(" + i + ")");
		link.appendChild(document.createTextNode(files[i].name));
		td.appendChild(link);
		table.tBodies[0].rows[i].appendChild(td);
		td = document.createElement("td");
		td.appendChild(document.createTextNode(files[i].size));
		table.tBodies[0].rows[i].appendChild(td);
	}
	output.appendChild(table);
	output.appendChild(document.createElement("p"));

}// File info End

function dumpFile(i) {
	var fr = new FileReader();

	fr.onabort = function() {
		alert("abort");
	};
	fr.onerror = function() {
		var msg = "";
		switch (fr.error) {
		case FileError.NOT_FOUND_ERR:
			msg = "not found";
			break;
		case FileError.SECURITY_ERR:
			msg = "security violation";
			break;
		case FileError.ABORT_ERR:
			msg = "abort";
			break;
		case FileError.NOT_READABLE_ERR:
			msg = "unreadable";
			break;
		case FileError.ENCODING_ERR:
			msg = "bad encoding";
			break;
		default: 	msg = "unknown";
		}
		alert(msg);
	};
	
	
	

	fr.onloadend = function() {
		if (output.lastChild.nodeName == "PRE")
			output.removeChild(output.lastChild);
		var pre = document.createElement("pre");
		output.appendChild(pre);
		var size = Math.min(128, files[i].size);
		for ( var j = 0; j < size; j++) {
			var hex = fr.result.charCodeAt(j).toString(16);
			if (hex.length == 1)
				hex += "0";
			pre.appendChild(document.createTextNode(hex));
			pre.appendChild(document.createTextNode(" "));
			if (j % 16 == 15) {
				pre.appendChild(document.createElement("br"));
			}
		}
	};

	fr.readAsBinaryString(files[i]);

}//dumpFile  end



