 $(document).ready(function(){
                $(".menu a").hover(function() {
                    $(this).next("span").animate({opacity:"show", top:"-220"}, "slow");
                }, function() {
                    $(this).next("span").animate({opacity:"hide", top:"-200"}, "fast");
                });
            });
