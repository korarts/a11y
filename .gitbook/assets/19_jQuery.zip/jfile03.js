    $(document).ready(function() {
                $('#add_table_last').click(function() {
                    $('#mytable tr:last').after('<tr><td>New last_name</td><td>New last nic_name</td></tr>');
                });

                $('#add_table_first').click(function() {
                    $('#mytable tr:first').after('<tr><td>NEW first_name</td><td>New first nic_name</td></tr>');
                });
                $('#remove_last').click(function() {                
                    $('#mytable tr:last').remove();                		
                });
                $('#remove_first').click(function() {
                    $('#mytable tr:eq(1)').remove();
                });
            });
    
