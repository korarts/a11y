
		function createXMLHttpRequest() {
			var xmlHttp = null;
			if (window.ActiveXObject) {
				xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
			}	else if (window.XMLHttpRequest) { 
				xmlHttp = new XMLHttpRequest();
			}
			return xmlHttp;

		}
		
		var btn = document.getElementById('send');
		
		
		btn.onclick = function(event) {
	
			var xmlHttp = createXMLHttpRequest();
			
			xmlHttp.open("GET", "sample.xml", true);		

			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
						printFileInfo(xmlHttp) ;
					}	
		        };
		        xmlHttp.send(null); 
		};

		function printFileInfo(xmlHttp) {

			var xmlData = xmlHttp.responseXML;

			var book = xmlData.getElementsByTagName("book");
			var title= xmlData.getElementsByTagName("title");
				var price=xmlData.getElementsByTagName("price");
					var author=xmlData.getElementsByTagName("author");
          var tvalue="",pvalue="",avalue="";
			for ( var i = 0; i < book.length; i++)			{
			
				 tvalue =title[i].childNodes[0].nodeValue;          
				 pvalue= price[i].childNodes[0].nodeValue;
				 avalue= author[i].childNodes[0].nodeValue;	
					insertRow(tvalue, pvalue, avalue);
			}
		

		}
		
	
		function insertRow(tvalue,pvalue, avalue) {

			var tablev = document.getElementById("resultTable");

			var rowv = document.createElement("tr");
			var tdv01 = document.createElement("td");
			var tdv02 = document.createElement("td"); 
			var tdv03 = document.createElement("td"); 

			rowv.style.textAlign = 'center';
			rowv.appendChild(tdv01);
			rowv.appendChild(tdv02);
			rowv.appendChild(tdv03);
			tdv01.innerHTML = tvalue;
			tdv02.innerHTML = pvalue;
			tdv03.innerHTML = avalue;		
			tablev.appendChild(rowv);



		}
