

var db;
window.onload = function() {
    db = openDatabase("BookList", "1.0", "책목록", 200000);
	db.transaction(function(e) {
		e.executeSql("create table if not exists BookList(no integer primary key autoincrement, title text, author text, price integer)");
		e.executeSql(	"insert into  BookList(title, author, price), values (?,?,?)", [
					"Getting Start java",	"Dominica", 30000]);
		e.executeSql("insert into  BookList(title, author, price) values (?,?,?)", ["안드로이드 이렇게 시작하세요","Dominica", 28000]);
		e.executeSql("insert into  BookList(title, author, price) values (?,?,?)", ["Getting Start HTML5",	"Dominica", 30000]);

	});
 allView();

};


if (window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB)
{
	     //indexedDB 코드 작성
}else {
	window.alert ( "이 브라우저에서는 IndexedDB를 사용할 수 없습니다");
	}





function insertBook()
{
           	   var title= document.getElementById("title").value;

           	   var author=document.getElementById("author").value;
           	   var price= document.getElementById("price").value;
	db.transaction(function(e) {
			e.executeSql(	"insert into  BookList(title, author, price) values (?,?,?)", [
					title,author,price]);
	});

};


function allView() {
	db.transaction(function(e) {
		e.executeSql(" select * from BookList", [], function(e, rs) {
			for ( var i = 0; i < rs.rows.length; i++) {
				var row = rs.rows.item(i);
				document.getElementById("table").innerHTML += "<tr><td>"
						+ row["no"] + "</td><td> " + row["title"]
						+ "</td><td> " + row["author"] +
						"</td><td> " + row["price"]  +
						"</td></tr>";
			};
		});
	});


	/*function deleteBook(no)	{
		db.transaction(function(e){
			    e. executeSql("delete from BookList where no=?", [no]);
		 }	);
		  allView();
		};*/

};









